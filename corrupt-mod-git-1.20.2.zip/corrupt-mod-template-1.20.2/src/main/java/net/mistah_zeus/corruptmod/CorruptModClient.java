package net.mistah_zeus.corruptmod;
import net.fabricmc.api.ClientModInitializer;
public class CorruptModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
